/* As shown in the lecture code: https://github.com/stevens-cs546-cs554/CS-554/tree/master/graphql */
export const mongoConfig = {
  serverUrl: 'mongodb://localhost:27017/',
  database: 'Octavio_Morales_Lab3'
};
