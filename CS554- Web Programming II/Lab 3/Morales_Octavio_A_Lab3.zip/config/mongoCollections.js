/* As shown in the lecture code: https://github.com/stevens-cs546-cs554/CS-554/tree/master/graphql */
import {dbConnection} from './mongoConnection.js';

const getCollectionFn = (collection) => {
  let _col = undefined;

  return async () => {
    if (!_col) {
      const db = await dbConnection();
      _col = await db.collection(collection);
    }

    return _col;
  };
};

export const authors = getCollectionFn('authors');
export const books = getCollectionFn('books');
export const publishers = getCollectionFn('publishers');
