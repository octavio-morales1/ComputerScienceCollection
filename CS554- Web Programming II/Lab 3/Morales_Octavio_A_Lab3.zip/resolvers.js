/* As shown in the lecture code: https://github.com/stevens-cs546-cs554/CS-554/tree/master/graphql */

import redis from 'redis';
import {authors as authorCollection} from './config/mongoCollections.js';
import {books as bookCollection} from './config/mongoCollections.js';
import {publishers as publisherCollection} from './config/mongoCollections.js';
import { GraphQLError } from 'graphql';
import { ObjectId } from 'mongodb';

const client= redis.createClient();
client.connect().catch(console.error);

const getData= async (key, expirationTime, queryFn) => {
  try{
    const cD= await client.get(key);
    if(cD) {
      return JSON.parse(cD);
    }
  }
  catch (error) {
    console.error('Error On Redis cache:', error);
  }
  const allData= await queryFn();

  try {
    await client.set(key, JSON.stringify(allData), 'EX', expirationTime);
  }
  catch (error) {
    console.error('Error setting Redis cache:', error);
  }
  return allData;
};

const isValidObjectId= (id) => {
  return ObjectId.isValid(id);
};

export const resolvers= {
  Query:
  {
    authors: async () => {
      return getData('authors', 3600, async () => {
        const coll= await authorCollection();
        return await coll.find({}).toArray();
      });
    },
    books: async () => {
      return getData('books', 3600, async () => {
        const coll= await bookCollection();
        return await coll.find({}).toArray();
      });
    },
    publishers: async () => {
      return getData('publishers', 3600, async () => {
        const coll= await publisherCollection();
        return await coll.find({}).toArray();
      });
    },
    getAuthorById: async (_, { _id }) => {
      if(!_id) {
        throw new GraphQLError('Invalid or missing Author ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(_id.trim()=== '') {
        throw new GraphQLError('Invalid or missing Author ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(typeof _id !== 'string') {
        throw new GraphQLError('Invalid or missing Author ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      _id= _id.trim();

      const temp2= await client.get(`author:${_id}`);
      if(temp2) {
        return JSON.parse(temp2);
      }

      const coll= await authorCollection();
      const author= await coll.findOne({ _id: _id });

      if(!author) {
        throw new GraphQLError('Author not found', { extensions: { code: 'NOT_FOUND' } });
      }

      await client.set(`author:${_id}`, JSON.stringify(author));
      return author;
    },
    getBookById: async (_, { _id }) => {
      if(!_id) {
        throw new GraphQLError('Missing Book ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof _id !== 'string') {
        throw new GraphQLError('Book ID must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }  
      if(_id.trim()=== '') {
        throw new GraphQLError('Book ID cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      _id= _id.trim();
      const mytemp= await client.get(`book:${_id}`);
      if(mytemp) {
        return JSON.parse(mytemp);
      }

      const coll= await bookCollection();
      const book= await coll.findOne({ _id: _id });

      if(!book) {
        throw new GraphQLError('Book not found', { extensions: { code: 'NOT_FOUND' } });
      }
      await client.set(`book:${_id}`, JSON.stringify(book));
      return book;
    },
    getPublisherById: async (_, { _id }) => {
      if(!_id || typeof _id !== 'string' || _id.trim()=== '') {
        throw new GraphQLError('Invalid or missing Publisher ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      _id= _id.trim();
      const tempP= await client.get(`publisher:${_id}`);
      if(tempP) {
        return JSON.parse(tempP);
      }

      const coll= await publisherCollection();
      const pub= await coll.findOne({ _id: _id });
      if(!pub) {
        throw new GraphQLError('Publisher not found', { extensions: { code: 'NOT_FOUND' } });
      }

      await client.set(`publisher:${_id}`, JSON.stringify(pub));
      return pub;
    },
    getChaptersByBookId: async (_, { bookId }) => {
      if(!bookId || typeof bookId !== 'string' || bookId.trim()=== '') {
        throw new GraphQLError('Invalid or missing Book ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      bookId= bookId.trim();

      const tempC= await client.get(`chapters:${bookId}`);
      if(tempC) {
        return JSON.parse(tempC);
      }

      const coll= await bookCollection();
      const book= await coll.findOne({ _id: bookId });

      if(!book) {
        throw new GraphQLError('Book not found', { extensions: { code: 'NOT_FOUND' } });
      }

      await client.set(`chapters:${bookId}`, JSON.stringify(book.chapters), 'EX', 3600);
      return book.chapters;
    },
    booksByGenre: async (_, { genre }) => {
      const tempAB= await client.get(`genre:${genre}`);
      if(tempAB) {
        return JSON.parse(tempAB);
      }

      const coll= await bookCollection();
      const books= await coll.find({ genre: genre }).toArray();

      await client.set(`genre:${genre}`, JSON.stringify(books), 'EX', 3600);
      return books;
    },
    publishersByEstablishedYear: async (_, { min, max }) => {
      if(min<= 0) {
        throw new GraphQLError('Minimum year must be greater than 0', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(max< min) {
        throw new GraphQLError('Maximum year must be greater than or equal to the minimum year', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(max> new Date().getFullYear() + 5) {
        throw new GraphQLError('Maximum year cannot be more than 5 years in the future', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      const tempAP= await client.get(`foundedYear:${min}:${max}`);
      if(tempAP) {
        return JSON.parse(tempAP);
      }

      const coll= await publisherCollection();
      const publishers= await coll.find({establishedYear: { $gte: min, $lte: max}}).toArray();

      await client.set(`foundedYear:${min}:${max}`, JSON.stringify(publishers), 'EX', 3600);
      return publishers;
    },
    searchAuthorByName: async (_, { searchTerm }) => {
      const tempAA= await client.get(`search:author:${searchTerm}`);
      if(tempAA) {
        return JSON.parse(tempAA);
      }

      const coll= await authorCollection();
      const authors= await coll.find({name: { $regex: searchTerm, $options: 'i' } }).toArray();
      await client.set(`search:author:${searchTerm}`, JSON.stringify(authors), 'EX', 3600);
      return authors;
    },
    searchBookByTitle: async (_, { searchTerm }) => {
      const tempBBT= await client.get(`search:book:${searchTerm}`);
      if(tempBBT) {
        return JSON.parse(tempBBT);
      }

      const coll= await bookCollection();
      const books= await coll.find({ title: { $regex: searchTerm, $options: 'i' }}).toArray();
      await client.set(`search:book:${searchTerm}`, JSON.stringify(books), 'EX', 3600);
      return books;
    }
  },
  Mutation: {
    addAuthor: async (_, args) => {
      const { name, bio, dateOfBirth }= args;
      if(!name) {
        throw new GraphQLError('Missing author name', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(typeof name !== 'string') {
        throw new GraphQLError('Author name must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(name.trim()=== '') {
        throw new GraphQLError('Author name cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(!dateOfBirth) {
        throw new GraphQLError('Missing date of birth', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(typeof dateOfBirth !== 'string') {
        throw new GraphQLError('Date of birth must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      if(dateOfBirth.trim()=== '') {
        throw new GraphQLError('Date of birth cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      try {
        const authors= await authorCollection();

        const newAuthor= {
          _id: new ObjectId().toString(),
          name: name.trim(),
          bio: bio ? bio.trim() : null,
          dateOfBirth: dateOfBirth.trim(),
          books: []
        };

        const insertInfo= await authors.insertOne(newAuthor);
        if(!insertInfo.acknowledged) {
          throw new GraphQLError('Insert operation was not acknowledged', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }
        
        if(!insertInfo.insertedId) {
          throw new GraphQLError('No inserted ID returned, could not add author', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }
        await client.del('authors');

        return newAuthor;
      }
      catch (error) {
        console.error('Error adding author:', error);
        throw new GraphQLError('Error adding author', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    },
    addPublisher: async (_, args) => {
      const { name, establishedYear, location }= args;
      if(!name) {
        throw new GraphQLError('Missing publisher name', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof name !== 'string') {
        throw new GraphQLError('Publisher name must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(name.trim()=== '') {
        throw new GraphQLError('Publisher name cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(!location) {
        throw new GraphQLError('Missing location', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof location !== 'string') {
        throw new GraphQLError('Location must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(location.trim()=== '') {
        throw new GraphQLError('Location cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof establishedYear !== 'number') {
        throw new GraphQLError('Established year must be a number', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(establishedYear<= 0) {
        throw new GraphQLError('Established year must be greater than 0', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      try {
        const publishers= await publisherCollection();

        const newPublisher= {
          _id: new ObjectId().toString(),
          name: name.trim(),
          establishedYear,
          location: location.trim(),
          books: []
        };

        const insertInfo= await publishers.insertOne(newPublisher);
        if(!insertInfo.acknowledged) {
          throw new GraphQLError('Insert operation was not acknowledged', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }
        if(!insertInfo.insertedId) {
          throw new GraphQLError('No inserted ID returned, could not add publisher', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }
        await client.del('publishers');

        return newPublisher;
      }
      catch (error) {
        console.error('Error adding publisher:', error);
        throw new GraphQLError('Error adding publisher', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    },
    addBook: async (_, args) => {
      const { title, publicationDate, genre, chapters, authorId, publisherId }= args;
      if(!title) {
        throw new GraphQLError('Missing book title', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof title !== 'string') {
        throw new GraphQLError('Book title must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(title.trim()=== '') {
        throw new GraphQLError('Book title cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(!publicationDate) {
        throw new GraphQLError('Missing publication date', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof publicationDate !== 'string') {
        throw new GraphQLError('Publication date must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(publicationDate.trim()=== '') {
        throw new GraphQLError('Publication date cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(!Array.isArray(chapters)) {
        throw new GraphQLError('Chapters must be an array', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(chapters.length=== 0) {
        throw new GraphQLError('Chapters array cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(chapters.some(ch => typeof ch !== 'string' || ch.trim()=== '')) {
        throw new GraphQLError('Each chapter must be a non-empty string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(!isValidObjectId(authorId)) {
        throw new GraphQLError('Invalid or missing author ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(!isValidObjectId(publisherId)) {
        throw new GraphQLError('Invalid or missing publisher ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }

      try {
        const books= await bookCollection();
        const authors= await authorCollection();
        const publishers= await publisherCollection();
        const authorExists= await authors.findOne({ _id: authorId });
        if(!authorExists) {
          throw new GraphQLError('Author not found', { extensions: { code: 'NOT_FOUND' } });
        }
        const publisherExists= await publishers.findOne({ _id: publisherId });
        if(!publisherExists) {
          throw new GraphQLError('Publisher not found', { extensions: { code: 'NOT_FOUND' } });
        }

        const newBook= {
          _id: new ObjectId().toString(),
          title: title.trim(),
          publicationDate: publicationDate.trim(),
          genre,
          authorId,
          publisherId,
          chapters: chapters.map(ch => ch.trim())
        };

        const insertInfo= await books.insertOne(newBook);
        if(!insertInfo.acknowledged) {
          throw new GraphQLError('Insert operation was not acknowledged', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }
        if(!insertInfo.insertedId) {
          throw new GraphQLError('No inserted ID returned, could not add book', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }        
        await authors.updateOne({ _id: authorId }, { $push: { books: newBook._id } });
        await publishers.updateOne({ _id: publisherId }, { $push: { books: newBook._id } });

        await client.del('books');
        await client.del(`author:${authorId}`);
        await client.del(`publisher:${publisherId}`);
        return newBook;
      }
      catch (error) {
        console.error('Error adding book:', error);
        throw new GraphQLError('Error adding book', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    },
    editAuthor: async (_, args) => {
      const { _id, name, bio, dateOfBirth }= args;

      if(!_id) {
        throw new GraphQLError('Missing author ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof _id !== 'string') {
        throw new GraphQLError('Author ID must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(_id.trim()=== '') {
        throw new GraphQLError('Author ID cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }

      const trimmedId= _id.trim();
      if(name) {
        if(typeof name !== 'string') {
          throw new GraphQLError('Author name must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        if(name.trim()=== '') {
          throw new GraphQLError('Author name cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
        }
      }
      if(dateOfBirth) {
        if(typeof dateOfBirth !== 'string') {
          throw new GraphQLError('Date of birth must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        if(dateOfBirth.trim()=== '') {
          throw new GraphQLError('Date of birth cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
        }
      }
      

      try {
        const authors= await authorCollection();

        const updatedData= {};
        if(name){
          updatedData.name= name.trim();
        }
        if(bio){
          updatedData.bio= bio.trim();
        }
        if(dateOfBirth){
          updatedData.dateOfBirth= dateOfBirth.trim();
        }
        if(Object.keys(updatedData).length=== 0) {
          throw new GraphQLError('No valid fields provided for update', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        

        const updatedAuthor= await authors.findOneAndUpdate(
          { _id: trimmedId },
          { $set: updatedData },
          { returnDocument: 'after' }
        );
        await client.del(`author:${trimmedId}`);
        await client.del('authors');

        return updatedAuthor.value;
      }
      catch (error) {
        console.error('Error editing author:', error);
        throw new GraphQLError('Error editing author', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    },
    editBook: async (_, args) => {
      const { _id, title, publicationDate, genre, chapters }= args;
      if(!_id) {
        throw new GraphQLError('Missing book ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof _id !== 'string') {
        throw new GraphQLError('Book ID must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(_id.trim()=== '') {
        throw new GraphQLError('Book ID cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      
      const trimmedId= _id.trim();
      if(title) {
        if(typeof title !== 'string') {
          throw new GraphQLError('Book title must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        if(title.trim()=== '') {
          throw new GraphQLError('Book title cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
        }
      }
      if(publicationDate) {
        if(typeof publicationDate !== 'string') {
          throw new GraphQLError('Publication date must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        if(publicationDate.trim()=== '') {
          throw new GraphQLError('Publication date cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
        }
      }
      if(chapters) {
        if(!Array.isArray(chapters)) {
          throw new GraphQLError('Chapters must be an array', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        if(chapters.some(ch => typeof ch !== 'string' || ch.trim()=== '')) {
          throw new GraphQLError('Each chapter must be a non-empty string', { extensions: { code: 'BAD_USER_INPUT' } });
        }
      }
      try {
        const books= await bookCollection();
        const updatedData= {};
        if(title) {
          updatedData.title= title.trim();
        }
        if(publicationDate) {
          updatedData.publicationDate= publicationDate.trim();
        }
        if(genre) {
          updatedData.genre= genre;
        }
        if(chapters) {
          updatedData.chapters= chapters.map(ch => ch.trim());
        }
        if(Object.keys(updatedData).length=== 0) {
          throw new GraphQLError('No valid fields provided for update', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        

        const updatedBook= await books.findOneAndUpdate(
          { _id: trimmedId },
          { $set: updatedData },
          { returnDocument: 'after' }
        );
        await client.del(`book:${trimmedId}`);
        await client.del('books');

        return updatedBook.value;
      }
      catch (error) {
        console.error('Error editing book:', error);
        throw new GraphQLError('Error editing book', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    },
    editPublisher: async (_, args) => {
      const { _id, name, establishedYear, location }= args;
      if(!_id) {
        throw new GraphQLError('Missing publisher ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof _id !== 'string') {
        throw new GraphQLError('Publisher ID must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(_id.trim()=== '') {
        throw new GraphQLError('Publisher ID cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      

      const trimmedId= _id.trim();

      if(name) {
        if(typeof name !== 'string') {
          throw new GraphQLError('Publisher name must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        if(name.trim()=== '') {
          throw new GraphQLError('Publisher name cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
        }
      }
      if(location) {
        if(typeof location !== 'string') {
          throw new GraphQLError('Location must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        if(location.trim()=== '') {
          throw new GraphQLError('Location cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
        }
      }
      if(establishedYear) {
        if(typeof establishedYear !== 'number') {
          throw new GraphQLError('Established year must be a number', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        if(establishedYear<= 0) {
          throw new GraphQLError('Established year must be greater than 0', { extensions: { code: 'BAD_USER_INPUT' } });
        }
      }      

      try {
        const publishers= await publisherCollection();
        const updatedData= {};
        if(name) {
          updatedData.name= name.trim();
        }
        if(establishedYear) {
          updatedData.establishedYear= establishedYear;
        }
        if(location) {
          updatedData.location= location.trim();
        }
        if(Object.keys(updatedData).length=== 0) {
          throw new GraphQLError('No valid fields provided for update', { extensions: { code: 'BAD_USER_INPUT' } });
        }
        

        const updatedPublisher= await publishers.findOneAndUpdate(
          { _id: trimmedId },
          { $set: updatedData },
          { returnDocument: 'after' }
        );
        await client.del(`publisher:${trimmedId}`);
        await client.del('publishers');

        return updatedPublisher.value;
      }
      catch (error) {
        console.error('Error editing publisher:', error);
        throw new GraphQLError('Error editing publisher', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    },
    removeAuthor: async (_, { _id }) => {
      if(!_id) {
        throw new GraphQLError('Missing author ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof _id !== 'string') {
        throw new GraphQLError('Author ID must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(_id.trim()=== '') {
        throw new GraphQLError('Author ID cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      

      const trimmedId= _id.trim();

      try {
        const authors= await authorCollection();
        const deletionInfo= await authors.deleteOne({ _id: trimmedId });

        if(deletionInfo.deletedCount=== 0) {
          throw new GraphQLError('Could not remove author', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }
        await client.del(`author:${trimmedId}`);
        await client.del('authors');

        return true;
      }
      catch (error) {
        console.error('Error removing author:', error);
        throw new GraphQLError('Error removing author', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    },
    removeBook: async (_, { _id }) => {
      if(!_id) {
        throw new GraphQLError('Missing book ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof _id !== 'string') {
        throw new GraphQLError('Book ID must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(_id.trim()=== '') {
        throw new GraphQLError('Book ID cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }      
      const trimmedId= _id.trim();

      try {
        const books= await bookCollection();
        const deletionInfo= await books.deleteOne({ _id: trimmedId });

        if(deletionInfo.deletedCount=== 0) {
          throw new GraphQLError('Could not remove book', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }
        await client.del(`book:${trimmedId}`);
        await client.del('books');

        return true;
      }
      catch (error) {
        console.error('Error removing book:', error);
        throw new GraphQLError('Error removing book', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    },
    removePublisher: async (_, { _id }) => {
      if(!_id) {
        throw new GraphQLError('Missing publisher ID', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(typeof _id !== 'string') {
        throw new GraphQLError('Publisher ID must be a string', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if(_id.trim()=== '') {
        throw new GraphQLError('Publisher ID cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }      

      const trimmedId= _id.trim();

      try {
        const publishers= await publisherCollection();
        const deletionInfo= await publishers.deleteOne({ _id: trimmedId });

        if(deletionInfo.deletedCount=== 0) {
          throw new GraphQLError('Could not remove publisher', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
        }
        await client.del(`publisher:${trimmedId}`);
        await client.del('publishers');

        return true;
      }
      catch (error) {
        console.error('Error removing publisher:', error);
        throw new GraphQLError('Error removing publisher', { extensions: { code: 'INTERNAL_SERVER_ERROR' } });
      }
    }
  },

  Author: {
    books: async (parent) => {
      const coll= await bookCollection();
      return coll.find({ authorId: parent._id }).toArray();
    },
    numOfBooks: async (parent) => {
      const coll= await bookCollection();
      return coll.countDocuments({ authorId: parent._id });
    }
  },
  Book: {
    author: async (parent) => {
      const coll= await authorCollection();
      return coll.findOne({ _id: parent.authorId });
    },
    publisher: async (parent) => {
      const coll= await publisherCollection();
      return coll.findOne({ _id: parent.publisherId });
    }
  },
  Publisher: {
    books: async (parent) => {
      const coll= await bookCollection();
      return coll.find({ publisherId: parent._id }).toArray();
    },
    numOfBooks: async (parent) => {
      const coll= await bookCollection();
      return coll.countDocuments({ publisherId: parent._id });
    }
  }
};
