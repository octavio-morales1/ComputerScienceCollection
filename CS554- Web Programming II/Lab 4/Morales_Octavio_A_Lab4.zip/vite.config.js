// Based on the lecture code: https://github.com/stevens-cs546-cs554/CS-554/blob/master/react_first_lecture/simple-component-example/vite.config.js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'

export default defineConfig({ plugins: [react()]})
