// Based on the lecture code and assignment instructions: https://github.com/stevens-cs546-cs554/CS-554/blob/master/react_first_lecture/simple-component-example/src/App.jsx
function TodoList({ todos, delT, comp }) {
  return (
    <div>
      {todos.map(todo => (
        <div key={todo.id} className={(() => {
          if (new Date(todo.due) < new Date()) {
            return 'overdue';
          }
          return '';
        })()}>
          <h1>{todo.title}</h1>
          <p>{todo.description}</p>
          <p>Due Date: {todo.due}</p>
          <p>Completed: No</p>
          <button onClick={() => delT(todo.id)}>Delete</button> {}
          <button onClick={() => comp(todo)}>Complete</button> {}
        </div>
      ))}
    </div>
  );
}

export default TodoList;
