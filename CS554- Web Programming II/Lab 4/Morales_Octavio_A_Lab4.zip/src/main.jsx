// Based on the lecture code and assignment instructions. In this case, it is essentially word for word: https://github.com/stevens-cs546-cs554/CS-554/blob/master/react_first_lecture/simple-component-example/src/main.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
