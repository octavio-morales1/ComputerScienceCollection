import {useState} from 'react';
import TodoList from './TodoList.jsx';
import CompletedTodos from './CompletedTodos.jsx';
import AddTodo from './AddTodo.jsx';

function App() {
  const initialTodos = [
    {id: 1, title: 'Submit My Homework', description: 'Submit my homework for my computer science class', due: '2024-10-22', completed: false },
    {id: 2, title: 'Cry About My Grade', description: 'Go over your grade for your homework, figure out what you got wrong, and start crying about it', due: '2024-10-29', completed: false },
    {id: 3, title: 'Senior Design Meeting', description: 'Attend the meeting for senior design and update the professor on your progress', due: '2024-10-30', completed: false },
    {id: 4, title: 'Stroll Practice', description: 'Attend stroll practice for your upcoming performance', due: '2024-11-04', completed: false },
    {id: 5, title: 'Hide The Evidence', description: 'No one knows that the methods used to do the senior design project are extremely illegal. No one must know. Go to Sandy Hook at 9:00 pm to meet the people that will hide your evidence.', due: '2024-11-05', completed: false },
    {id: 6, title: 'Dinner With Uncle Lucho', description: "It is that day! It is your uncle's birthday! Go have fun and eat dinner with him!", due: '2024-11-06', completed: false },
    {id: 7, title: 'Meeting With Aunt Cynthia', description: 'You want the best senior design project. You do not want this to be a project, you want it to be history. You want the investors early so this can be a hit. You need all resources to get an edge on this. Aunt Cynthia has such connections, but it is in the morally wrong area. However, you want this. Your uncle would not understand. That is why he will not be at the meeting, which is at 10:00 pm.', due: '2024-11-07', completed: false },
    {id: 8, title: 'Buy New Computer Parts', description: 'Go to Micro Center to buy some new computer parts! The personal computer upgrade is long overdue.', due: '2024-11-10', completed: false },
    {id: 9, title: 'Pay The Phone Bill', description: 'Pay the phone bill to T-Mobile by midnight by November 12th.', due: '2024-11-12', completed: false },
    {id: 10, title: 'Senior Design Meeting II', description: 'Meeting with your professor for senior design. Make sure all evidence is untraceable by November 13th. No one must know, even if it means losing everyone you cared about. You will be the best. You will change the world.', due: '2024-11-13', completed: false },
  ];

  const [todos, setTodos] = useState(initialTodos);

  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const toggleCompleted = (todo) => {
    setTodos(todos.map(currentTodo =>
      currentTodo.id === todo.id
        ? {...currentTodo, completed: !currentTodo.completed }
        : currentTodo
    ));
  };

  const addTodo = (newTodo) => {
    setTodos([
      ...todos,
      { id: todos.length + 1, title: newTodo.title, description: newTodo.description, due: newTodo.due, completed: false }
    ]);
  };  

  return (
    <div>
      <h1>Todo Application</h1>
      <TodoList todos={todos.filter(todo => !todo.completed)} delT={deleteTodo} comp={toggleCompleted} />
      <CompletedTodos todoList={todos.filter(todo => todo.completed)} toggleCompleted={toggleCompleted} />
      <AddTodo addTodo={addTodo} />
    </div>
  );
}

export default App;
