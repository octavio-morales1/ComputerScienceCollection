import { useState } from 'react';

function AddTodo({ addTodo }) {
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDetails, setTaskDetails] = useState('');
  const [deadline, setDeadline] = useState('');

  const handleFormSubmit = (event) => {
    event.preventDefault();

    if (taskTitle.trim().length > 4 && taskDetails.trim().length >= 25 && new Date(deadline) >= new Date()) {
      addTodo({
        title: taskTitle,
        description: taskDetails,
        due: new Date(deadline).toLocaleDateString()
      });
      clearForm();
    } else {
      alert("Please ensure the title is at least 5 characters and the description is at least 25 characters.");
    }
  };

  const clearForm = () => {
    setTaskTitle('');
    setTaskDetails('');
    setDeadline('');
  };

  return (
    <form onSubmit={handleFormSubmit}>
      <input 
        type="text" 
        placeholder="Task Title" 
        value={taskTitle} 
        onChange={(event) => setTaskTitle(event.target.value)} 
      />
      <textarea 
        placeholder="Task Description" 
        value={taskDetails} 
        onChange={(event) => setTaskDetails(event.target.value)} 
      />
      <input 
        type="date" 
        value={deadline} 
        onChange={(event) => setDeadline(event.target.value)} 
        min={new Date().toISOString().split('T')[0]}
      />
      <button type="submit">Add Task</button>
    </form>
  );
}

export default AddTodo;
