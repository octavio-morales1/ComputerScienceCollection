// Based on the lecture code to display the completed To Dos: https://github.com/stevens-cs546-cs554/CS-554/blob/master/react_first_lecture/simple-component-example/src/App.jsx
function CompletedTodos({ todoList, toggleCompleted }) {
  return (
    <div>
      {todoList.map(todo => (
        <div key={todo.id}>
          <h1>{todo.title}</h1>
          <p>{todo.description}</p>
          <p>Due Date: {todo.due}</p>
          <p>Completed: Yes</p>
          <button onClick={() => toggleCompleted(todo)}>Mark Incomplete</button>
        </div>
      ))}
    </div>
  );
}

export default CompletedTodos;

  