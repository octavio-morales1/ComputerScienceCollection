//formatting and styling is basically from cs 546 and lecture code.
import movieRoutes from './movies.js';

const constructorMethod = (app) => {
  app.use('/api/movies', movieRoutes);

  app.use('*', (req, res) => {
    res.status(404).json({ error: 'Route Not Found' });
  });
};

export default constructorMethod;
