//formatting and styling is basically from cs 546 and lecture code.
import { Router } from 'express';
const router = Router();
import { moviesData } from '../data/index.js';
import validation from '../validation.js';

router.get('/', async (req, res) => {
  const skip= parseInt(req.query.skip) || 0;
  const take = parseInt(req.query.take) || 20;
  try {
    const movieList= await moviesData.getAllMovies(skip, take);
    return res.json(movieList);
  }
  catch(e) {
    return res.status(400).json({ error: e });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const movieId= validation.checkId(req.params.id, 'Movie ID');
    const movie= await moviesData.getMovieById(movieId);
    return res.json(movie);
  } catch (e) {
    return res.status(404).json({ error: e });
  }
});

router.post('/', async (req, res) => {
  const movieData= req.body;
  if (!movieData || Object.keys(movieData).length=== 0) {
    return res.status(400).json({ error: 'No data provided' });
  }
  try {
    const newMovie= await moviesData.addMovie(
      movieData.title,
      movieData.cast,
      movieData.info,
      movieData.plot,
      movieData.rating
    );
    return res.json(newMovie);
  } catch (e) {
    return res.status(400).json({ error: e });
  }
});

router.put('/:id', async (req, res) => {
  const updatedData= req.body;
  if (!updatedData || Object.keys(updatedData).length=== 0) {
    return res.status(400).json({ error: 'No data provided' });
  }
  try {
    req.params.id= validation.checkId(req.params.id, 'Movie ID');
    const updatedMovie= await moviesData.updateMovie(req.params.id, updatedData);
    return res.json(updatedMovie);
  } catch (e) {
    return res.status(400).json({ error: e });
  }
});

router.patch('/:id', async (req, res) => {
  const updatedData= req.body;
  if (!updatedData || Object.keys(updatedData).length=== 0) {
    return res.status(400).json({ error: 'No data provided' });
  }
  try {
    req.params.id= validation.checkId(req.params.id, 'Movie ID');
    const updatedMovie= await moviesData.updateMoviePatch(req.params.id, updatedData);
    return res.json(updatedMovie);
  } catch (e) {
    return res.status(400).json({ error: e });
  }
});

router.post('/:id/comments', async (req, res) => {
  const { name, comment }= req.body;
  try {
    req.params.id= validation.checkId(req.params.id, 'Movie ID');
    const updatedMovie= await moviesData.addComment(req.params.id, name, comment);
    return res.json(updatedMovie);
  } catch (e) {
    return res.status(400).json({ error: e });
  }
});

router.delete('/:movieId/:commentId', async (req, res) => {
  try {
    req.params.movieId= validation.checkId(req.params.movieId, 'Movie ID');
    req.params.commentId= validation.checkId(req.params.commentId, 'Comment ID');
    const updatedMovie= await moviesData.deleteComment(req.params.movieId, req.params.commentId);
    return res.json(updatedMovie);
  } catch (e) {
    return res.status(400).json({ error: e });
  }
});

export default router;
