import { ObjectId } from 'mongodb';

const exportedMethods = {
  checkId(id, vM) {
    if (!id){
      throw `Error: You must provide a ${vM}`;
    }
    if (typeof id !== 'string'){
      throw `Error: ${vM} must be a string`;
    }
    id = id.trim();
    if (id.length === 0){
      throw `Error: ${vM} cannot be an empty string or just spaces`;
    }
    if (!ObjectId.isValid(id)) {
      throw `Error: ${vM} invalid object ID`;
    }
    return id;
  },

  checkString(strVal, vM) {
    if (!strVal){
      throw `Error: You must supply a ${vM}!`;
    }
    if (typeof strVal!== 'string'){
      throw `Error: ${vM} must be a string!`;
    }
    strVal= strVal.trim();
    if (strVal.length=== 0){
      throw `Error: ${vM} cannot be an empty string or string with just spaces`;
    }
    if (!isNaN(strVal)){
      throw `Error: ${strVal} is not a valid value for ${vM} as it only contains digits`;
    }
    return strVal;
  },

  checkPositiveInteger(val, vM, max) {
    if (val=== undefined || val === null){
      throw `Error: You must provide a ${vM}`;
    }
    if (typeof val!== 'number' || val< 0 || !Number.isInteger(val)){
      throw `Error: ${vM} must be a positive integer`;
    }
    if (max && val > max){
      throw `Error: ${vM} cannot exceed ${max}`;
    }
    return val;
  },

  checkNumber(val, vM, min, max) {
    if (typeof val !== 'number' || isNaN(val)){
      throw `Error: ${vM} must be a number`;
    }
    if (val < min || val > max){
      throw `Error: ${vM} must be between ${min} and ${max}`;
    }
    return val;
  },

  checkCast(cast) {
    if (!Array.isArray(cast)){
      throw 'Error: Cast must be an array';
    }
    cast.forEach((member) => {
      if (typeof member.firstName !== 'string' || typeof member.lastName !== 'string') {
        throw 'Error: Each cast member must have a firstName and lastName as strings';
      }
    });
    return cast;
  },

  checkInfo(info) {
    if (typeof info !== 'object' || !info.director || !info.yearReleased){
      throw 'Error: Info must be an object containing a director and yearReleased';
    }
    if (typeof info.director !== 'string'){
      throw 'Error: Director must be a string';
    }
    if (typeof info.yearReleased !== 'number' || info.yearReleased < 1800){
      throw 'Error: Not a valid year number';
    }
    return info;
  }
};

export default exportedMethods;
