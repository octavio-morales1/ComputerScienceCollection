//formatting and styling is basically from cs 546 and lecture code.
export const mongoConfig = {
    serverUrl: 'mongodb://localhost:27017/',
    database: 'Morales-Octavio-CS554-Lab1'
  };
  