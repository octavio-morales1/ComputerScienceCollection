//formatting and styling is basically from cs 546 and lecture code.

import { movies } from '../config/mongoCollections.js';
import { ObjectId } from 'mongodb';
import validation from '../validation.js';

const exportedMethods= {
  async getAllMovies(skip = 0, take = 20) {
    skip= validation.checkPositiveInteger(skip, 'skip');
    take= validation.checkPositiveInteger(take, 'take', 100);
    const movieCollection= await movies();
    const movieList= await movieCollection.find({}).skip(skip).limit(take).toArray();
    return movieList;
  },

  async getMovieById(id) {
    id= validation.checkId(id, 'Movie ID');
    const movieCollection= await movies();
    const movie= await movieCollection.findOne({ _id: new ObjectId(id) });
    if (!movie){
      throw 'Error: Movie not found';
    }
    return movie;
  },

  async addMovie(title, cast, info, plot, rating) {
    title= validation.checkString(title, 'Title');
    cast= validation.checkCast(cast);
    info= validation.checkInfo(info);
    plot= validation.checkString(plot, 'Plot');
    rating= validation.checkNumber(rating, 'Rating', 0, 5);

    const newMovie={
      _id: new ObjectId(),
      title,
      cast,
      info,
      plot,
      rating,
      comments: []
    };
    const movieCollection= await movies();
    const insertInfo= await movieCollection.insertOne(newMovie);
    if (!insertInfo.acknowledged){
      throw 'Error: Could not add movie';
    }
    return await this.getMovieById(newMovie._id.toString());
  },

  async updateMovie(id, updatedMovie) {
    id= validation.checkId(id, 'Movie ID');
    //Free me please. I forgout 546 so reviewing was terrible.
    updatedMovie.title= validation.checkString(updatedMovie.title, 'Title');
    updatedMovie.cast= validation.checkCast(updatedMovie.cast);
    updatedMovie.info= validation.checkInfo(updatedMovie.info);
    updatedMovie.plot= validation.checkString(updatedMovie.plot, 'Plot');
    updatedMovie.rating= validation.checkNumber(updatedMovie.rating, 'Rating', 0, 5);

    const movieCollection= await movies();
    const updateInfo= await movieCollection.findOneAndReplace({ _id: new ObjectId(id) }, updatedMovie, { returnDocument: 'after' });
    if (!updateInfo.value){
      throw `Error: Update failed! Could not update movie with id ${id}`
    };
    return updateInfo.value;
  },

  async updateMoviePatch(id, updatedFields) {
    id= validation.checkId(id, 'Movie ID');
    const updateData= {};
    if (updatedFields.title){
      updateData.title= validation.checkString(updatedFields.title, 'Title');
    }
    if (updatedFields.cast){
      updateData.cast= validation.checkCast(updatedFields.cast);
    }
    if (updatedFields.info){
      updateData.info= validation.checkInfo(updatedFields.info);
    }
    if (updatedFields.plot){
      updateData.plot= validation.checkString(updatedFields.plot, 'Plot');
    }
    if (updatedFields.rating){
      updateData.rating= validation.checkNumber(updatedFields.rating, 'Rating', 0, 5);
    }

    const movieCollection= await movies();
    const updateInfo= await movieCollection.updateOne({ _id: new ObjectId(id) }, { $set: updateData });
    if (updateInfo.matchedCount=== 0){
      throw `Error: Could not find movie with id ${id}`;
    }
    return await this.getMovieById(id);
  },

  async addComment(movieId, name, comment) {
    movieId= validation.checkId(movieId, 'Movie ID');
    name= validation.checkString(name, 'Name');
    comment= validation.checkString(comment, 'Comment');
    const newComment= {
      _id: new ObjectId(),
      name,
      comment
    };

    const movieCollection= await movies();
    const updateInfo= await movieCollection.updateOne({ _id: new ObjectId(movieId) }, { $push: { comments: newComment } });
    if (!updateInfo.matchedCount){
      throw `Error: Could not find movie with id ${movieId}`;
    }
    return await this.getMovieById(movieId);
  },

  async deleteComment(movieId, commentId) {
    movieId= validation.checkId(movieId, 'Movie ID');
    commentId= validation.checkId(commentId, 'Comment ID');

    const movieCollection= await movies();
    const updateInfo= await movieCollection.updateOne(
      { _id: new ObjectId(movieId) }, { $pull: { comments: { _id: new ObjectId(commentId)}}}
    );
    if (!updateInfo.matchedCount){
      throw `Error: Could not find movie with id ${movieId}`;
    }
    if (!updateInfo.modifiedCount){
      throw `Error: Could not delete comment with id ${commentId}`;
    }
    return await this.getMovieById(movieId);
  }
};

export default exportedMethods;
