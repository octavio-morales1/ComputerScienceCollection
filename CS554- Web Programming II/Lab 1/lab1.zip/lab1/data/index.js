import moviesDataFunctions from './movies.js';
export const moviesData= moviesDataFunctions;
