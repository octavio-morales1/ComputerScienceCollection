let rC = 0;
const ctr = {};

const LRC = (req, res, next) => {
  rC++;
  console.log(`Total requests: ${rC}`);
  next();
};

const LRD= (req, res, next) => {
  console.log(`Request URL: ${req.originalUrl} ; HTTP Used: ${req.method} ; Body: ${JSON.stringify(req.body)}`);
  next();
};

const LURC= (req, res, next) => {
  if (!ctr[req.originalUrl]) {
    ctr[req.originalUrl]= 0;
  }
  ctr[req.originalUrl]++;
  console.log(`${req.originalUrl} has been requested ${ctr[req.originalUrl]} times`);
  next();
};

export { LRC, LRD, LURC };
