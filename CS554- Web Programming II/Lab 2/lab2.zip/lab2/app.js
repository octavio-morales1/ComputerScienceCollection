const express = require('express');
const app = express();
const configRoutes = require('./routes');
const redis = require('redis');
const client = redis.createClient();
client.connect().then(() => console.log('Connected to Redis'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
configRoutes(app);

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
