const redis= require('redis');
const client= redis.createClient();
client.connect().then(() => {});

// Give me mercy when grading this. I got really confused on the cache, so I tried making a new file away from everything else to make my life easier.
// This essentially doesn't even work on anything except for pokemon, SPECIFICALLY the history. Had to learn from online to do this, which was still annoying
// TLDR: I hate redis. I tried making my own as a project over the summer and it was terrible.

const checkCache=(kP)=>{
  return async(req, res, next)=>{
    const key= kP ? `${kP}:${req.params.id}` : kP;
    const cach= await client.get(key);
    if (cach){
      console.log(`${kP || 'Data'} from cache`);
      if (kP==='pokemon'){
        await client.lPush('recentlyViewed', cach);
        await client.lTrim('recentlyViewed', 0, 24);
      }
      res.json(JSON.parse(cach));
    }
    else{
      next();
    }
  };
};

module.exports= {checkCache};
