const pR= require('./pokemon');
const mR= require('./move');
const iR= require('./item');

const constructorMethod = (app) => {
  app.use('/api/pokemon', pR);
  app.use('/api/move', mR);
  app.use('/api/item', iR);

  app.use('*', (req, res) => {
    res.status(404).json({ error: 'Route no valid' });
  });
};

module.exports = constructorMethod;
