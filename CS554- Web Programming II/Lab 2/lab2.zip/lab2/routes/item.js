const express= require('express');
const router= express.Router();
const redis= require('redis');
const client= redis.createClient();
const axios= require('axios');
const { checkCache }= require('../middleware/cacheMiddleware');
client.connect().then(() => console.log('Connected to Redis'));

router.get('/', checkCache('itemList'), async (req, res) => {
  try{
    console.log('Item list not cached, fetching from API');
    const {data}= await axios.get('https://pokeapi.co/api/v2/item?limit=100');
    await client.set('itemList', JSON.stringify(data.results));
    res.status(200).json(data.results);

  }
  catch(error){
    console.error('Error fetching item list:', error);
    res.status(500).json({ error: 'Failed to retrieve item list' });
  }
});

router.get('/:id', checkCache('item'), async (req, res) => {
  const itemId = req.params.id;
  try {
    console.log(`Fetching item with ID ${itemId}`);
    const {data}=await axios.get(`https://pokeapi.co/api/v2/item/${itemId}`);
    await client.set(`item:${itemId}`, JSON.stringify(data));
    res.status(200).json(data);
  } 
  catch(error){
    console.error('Error fetching item data:', error);
    res.status(404).json({ error: 'Item not found' });
  }
});

module.exports = router;
