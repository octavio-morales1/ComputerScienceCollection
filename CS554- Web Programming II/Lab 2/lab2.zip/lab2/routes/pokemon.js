const express= require('express');
const router= express.Router();
const redis= require('redis');
const client= redis.createClient();
const axios= require('axios');
const {checkCache}= require('../middleware/cacheMiddleware');
client.connect().then(() => {});

router.get('/', checkCache('pokemonList'), async (req, res) => {
  try {
    console.log('Pokémon list not cached, fetching from API');
    const {data}= await axios.get('https://pokeapi.co/api/v2/pokemon?limit=100');
    await client.set('pokemonList', JSON.stringify(data.results));
    res.json(data.results);
  }
  catch(error){
    console.error('Error fetching Pokémon list:', error);
    res.status(500).json({error: 'Failed to retrieve Pokémon list'});
  }
});

router.get('/history', async (req, res) => {
  try{
    console.log('Fetching viewed Pokémon from Redis (Max 25 Pokemon)');
    const recentlyViewed = await client.lRange('recentlyViewed', 0, 24);
    
    if (!recentlyViewed || recentlyViewed.length === 0) {
      res.status(404).json({ error: 'No recently viewed Pokémon found' });
      return;
    }
    
    const parsedData = recentlyViewed.map((pokemon) => JSON.parse(pokemon));
    
    res.json(parsedData);
  } catch (error) {
    console.error('Error fetching recently viewed Pokémon:', error);
    res.status(500).json({ error: 'Unable to retrieve history' });
  }
});

router.get('/:id', checkCache('pokemon'), async (req, res) => {
  const pokemonId = req.params.id;
  try{
    console.log(`Fetching Pokémon with ID ${pokemonId}`);
    const { data } = await axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemonId}`);
    await client.set(`pokemon:${pokemonId}`, JSON.stringify(data));
    await client.lPush('recentlyViewed', JSON.stringify(data));
    await client.lTrim('recentlyViewed', 0, 24);
    res.json(data);

  }
  catch (error) {
    console.error('Error fetching Pokémon data:', error);
    res.status(404).json({ error: 'Pokémon not found' });
  }
});

module.exports = router;
