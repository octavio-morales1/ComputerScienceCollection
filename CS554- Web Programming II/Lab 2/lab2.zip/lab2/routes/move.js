const express= require('express');
const router= express.Router();
const redis= require('redis');
const client= redis.createClient();
const axios= require('axios');
const { checkCache }= require('../middleware/cacheMiddleware');
client.connect().then(() => console.log('Connected to Redis'));

router.get('/', checkCache('moveList'), async (req, res) => {
  try {
    console.log('Move list not cached, fetching from API');
    const {data}= await axios.get('https://pokeapi.co/api/v2/move?limit=100');
    await client.set('moveList', JSON.stringify(data.results));
    res.status(200).json(data.results);
  }

  catch (error){
    console.error('Error fetching move list:', error);
    res.status(500).json({error: 'Failed to retrieve move list'});
  }
});

router.get('/:id', checkCache('move'), async (req, res) => {
  const moveId= req.params.id;
  try{
    console.log(`Fetching move with ID ${moveId}`);
    const {data}= await axios.get(`https://pokeapi.co/api/v2/move/${moveId}`);
    await client.set(`move:${moveId}`, JSON.stringify(data));
    res.status(200).json(data);

  }
  catch(error){
    console.error('Error fetching move data:', error);
    res.status(404).json({error: 'Move not found'});
  }
});

module.exports = router;
