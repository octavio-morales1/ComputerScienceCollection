import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './components/Home';
import EventsList from './components/EventsList';
import EventDetails from './components/EventDetails';
import AttractionsList from './components/AttractionsList';
import AttractionDetails from './components/AttractionDetails';
import VenuesList from './components/VenuesList';
import VenueDetails from './components/VenueDetails';
import SearchEvents from './components/SearchEvents';
import SearchAttractions from './components/SearchAttractions';
import SearchVenues from './components/SearchVenues';

function App() {
  return (
    <Router>
      <div className="App">
        <header>
          <h1>Ticketmaster Events</h1>
          <nav>
            <Link to="/">Home</Link> | <Link to="/events/page/1">Events</Link> | 
            <Link to="/attractions/page/1">Attractions</Link> | 
            <Link to="/venues/page/1">Venues</Link> | 
            <Link to="/search/events">Search Events</Link> | 
            <Link to="/search/attractions">Search Attractions</Link> | 
            <Link to="/search/venues">Search Venues</Link>
          </nav>
        </header>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/events/page/:page" element={<EventsList />} />
          <Route path="/events/:id" element={<EventDetails />} />
          <Route path="/attractions/page/:page" element={<AttractionsList />} />
          <Route path="/attractions/:id" element={<AttractionDetails />} />
          <Route path="/venues/page/:page" element={<VenuesList />} />
          <Route path="/venues/:id" element={<VenueDetails />} />
          <Route path="/search/events" element={<SearchEvents />} />
          <Route path="/search/attractions" element={<SearchAttractions />} />
          <Route path="/search/venues" element={<SearchVenues />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
