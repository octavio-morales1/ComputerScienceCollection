import axios from 'axios';

export const fetchEvents=async (page) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/events`, {params: {apikey:'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0', countryCode: 'US', page: page-1 },});
  return temp.data;
};

export const fetchEventById=async (id) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/events/${id}`, {params:{apikey:'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0'},});
  return temp.data;
};

export const fetchAttractions=async (page) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/attractions`, {params: {apikey: 'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0', countryCode: 'US', page: page - 1 },});
  return temp.data;
};

export const fetchAttractionById=async (id) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/attractions/${id}`, {params: {apikey: 'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0' },});
  return temp.data;
};

export const fetchVenues=async (page) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/venues`, {params: {apikey: 'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0', countryCode:'US', page: page-1 },});
  return temp.data;
};

export const fetchVenueById=async (id) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/venues/${id}`, {params: {apikey: 'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0' },});
  return temp.data;
};

export const searchEvents=async (query) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/events`, {params: {apikey: 'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0', countryCode: 'US', keyword: query },});
  return temp.data;
};

export const searchAttractions=async (query) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/attractions`, {params: {apikey: 'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0', countryCode: 'US', keyword: query },});
  return temp.data;
};

export const searchVenues=async (query) =>{
  const temp=await axios.get(`${'https://app.ticketmaster.com/discovery/v2'}/venues`, {params: { apikey: 'R4kxcFxCJzuacsK3yxA81pypZyQzEdE0', countryCode: 'US', keyword: query },});
  return temp.data;
};
