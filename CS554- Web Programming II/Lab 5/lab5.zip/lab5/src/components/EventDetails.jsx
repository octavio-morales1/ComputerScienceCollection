import React, {useState, useEffect} from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchEventById } from '../api';

const EventDetails= ()=> {
  const { id }= useParams();
  const [event, setEvent]= useState(null);
  const navigate= useNavigate();

  useEffect(()=> {
    const getEvent= async ()=> {
      try {
        const data= await fetchEventById(id);
        setEvent(data);
      } catch (e) {
        navigate('/404');
      }
    };
    getEvent();
  }, [id, navigate]);

  return (
    <div>
      {event ? (
        <>
          <h2>{event.name}</h2>
          <p>{event.info}</p>
          <p>Start Date: {event.dates.start.localDate}</p>
        </>
      )
      :(
        <p>Loading...</p>
      )}
    </div>
  );
};

export default EventDetails;
