import React, {useState} from 'react';
import {searchEvents} from '../api';
import {Link} from 'react-router-dom';

const SearchEvents=() => {
  const [query, setQuery]=useState('');
  const [results, setResults]=useState([]);
  const [loading, setLoading]=useState(false);

  const handleSearch=async (e) => {
    e.preventDefault();
    setLoading(true);
    try{
      const temp= await searchEvents(query);
      setResults(temp._embedded?.events || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1>Search Events</h1>
      <form onSubmit={handleSearch}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for events"
        />
        <button type="submit">Search</button>
      </form>
      {loading ? (
        <p>Loading...</p>)
        :(
        results.map((event) => (
          <div key={event.id}>
            <Link to={`/events/${event.id}`}>{event.name}</Link>
          </div>
        ))
      )}
    </div>
  );
};

export default SearchEvents;
