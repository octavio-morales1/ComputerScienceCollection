import React, {useState, useEffect} from 'react';
import {useParams, useNavigate} from 'react-router-dom';
import {fetchAttractionById} from '../api';

const AttractionDetails=()=> {
  const {id}= useParams();
  const [attraction, setAttraction]= useState(null);
  const navigate= useNavigate();

  useEffect(()=> {
    const getAttraction= async ()=> {
      try {
        const data= await fetchAttractionById(id);
        setAttraction(data);
      }
      catch(e) {
        navigate('/404');
      }
    };
    getAttraction();
  },
  [id, navigate]);
  return(
    <div>
      {attraction?(
        <>
          <h2>{attraction.name}</h2>
          <p>{attraction.info || 'No additional information available.'}</p>
        </>
      )
      :(
        <p>Loading...</p>
      )}
    </div>
  );
};

export default AttractionDetails;
