import React, {useState, useEffect} from 'react';
import {useParams, Link} from 'react-router-dom';
import {fetchAttractions} from '../api';
import Pagination from './Pagination';

const AttractionsList= ()=> {
  const {page}= useParams();
  const [attractions, setAttractions]= useState([]);
  const [loading, setLoading]= useState(true);
  const [totalPages, setTotalPages]= useState(1);

  useEffect(()=> {
    const getAttractions= async ()=> {
      setLoading(true);
      try{
        const data= await fetchAttractions(page);
        setAttractions(data._embedded?.attractions || []);
        setTotalPages(data.page.totalPages);
      }
      catch(e){
        console.error(e);
      }
      finally{
        setLoading(false);
      }
    };
    getAttractions();
  }, [page]);

  return (
    <div>
      <h1>Attractions</h1>
      {loading ? (<p>Loading...</p>
      )
      :(
        attractions.map((attraction)=> (
          <div key={attraction.id}>
            <Link to={`/attractions/${attraction.id}`}>{attraction.name}</Link>
          </div>
        ))
      )}
      <Pagination currentPage={parseInt(page)} totalPages={totalPages} path="/attractions/page/" />
    </div>
  );
};

export default AttractionsList;
