import React, {useState} from 'react';
import {searchVenues} from '../api';
import {Link} from 'react-router-dom';

const SearchVenues=()=> {
  const [query, setQuery]=useState('');
  const [results, setResults]=useState([]);
  const [loading, setLoading]=useState(false);

  const handleSearch=async (e) => {
    e.preventDefault();
    setLoading(true);
    try{
      const temp=await searchVenues(query);
      setResults(temp._embedded?.venues || []);
    }
    catch(e){
      console.error(e);
    }
    finally{
      setLoading(false);
    }
  };
  return (
    <div>
      <h1>Search Venues</h1>
      <form onSubmit={handleSearch}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for venues"
        />
        <button type="submit">Search</button>
      </form>
      {loading ? (
        <p>Loading...</p>)
        :(
        results.map((venue) => (
          <div key={venue.id}>
            <Link to={`/venues/${venue.id}`}>{venue.name}</Link>
          </div>
        ))
      )}
    </div>
  );
};

export default SearchVenues;
