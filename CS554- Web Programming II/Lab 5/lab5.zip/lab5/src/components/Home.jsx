import React from 'react';
import { Link } from 'react-router-dom';

const Home=() => (
  <div>
    <h1>Ticketmaster Events (By Octavio Morales)</h1>
    <Link to="/events/page/1">Browse Events</Link>
    <Link to="/attractions/page/1">Browse Attractions</Link>
    <Link to="/venues/page/1">Browse Venues</Link>
  </div>
);

export default Home;
