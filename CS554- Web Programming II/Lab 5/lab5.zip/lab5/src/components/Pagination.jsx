import React from 'react';
import {Link} from 'react-router-dom';

const Pagination=({cP, tP, path})=> {
  return(
    <div>
      {cP> 1 && <Link to={`${path}${cP - 1}`}>Previous</Link>}
      {cP< tP && <Link to={`${path}${cP + 1}`}>Next</Link>}
    </div>
  );
};

export default Pagination;
