import React, {useState, useEffect} from 'react';
import {useParams, Link} from 'react-router-dom';
import {fetchVenues} from '../api';
import Pagination from './Pagination';

const VenuesList=() => {
  const {page}=useParams();
  const [venues, setVenues]=useState([]);
  const [loading, setLoading]=useState(true);
  const [totalPages, setTotalPages]=useState(1);

  useEffect(()=> {
    const getVenues=async () => {
      setLoading(true);
      try{
        const data=await fetchVenues(page);
        setVenues(data._embedded?.venues || []);
        setTotalPages(data.page.totalPages);
      }
      catch (e){
        console.error(e);
      }
      finally{
        setLoading(false);
      }
    };
    getVenues();
  }, [page]);

  return (
    <div>
      <h1>Venues</h1>
      {loading ? (
        <p>Loading...</p>
      )
      :(
        venues.map((venue) => (
          <div key={venue.id}>
            <Link to={`/venues/${venue.id}`}>{venue.name}</Link>
          </div>
        ))
      )}
      <Pagination currentPage={parseInt(page)} totalPages={totalPages} path="/venues/page/" />
    </div>
  );
};

export default VenuesList;
