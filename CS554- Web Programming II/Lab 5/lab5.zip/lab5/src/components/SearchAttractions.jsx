import React, {useState} from 'react';
import {searchAttractions} from '../api';
import {Link} from 'react-router-dom';

const SearchAttractions=() => {
  const [query, setQuery]=useState('');
  const [results, setResults]=useState([]);
  const [loading, setLoading]=useState(false);

  const handleSearch= async(e) => {
    e.preventDefault();
    setLoading(true);
    try{
      const data=await searchAttractions(query);
      setResults(data._embedded?.attractions || []);
    }
    catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1>Search Attractions</h1>
      <form onSubmit={handleSearch}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for attractions"
        />
        <button type="submit">Search</button>
      </form>
      {loading ? (
        <p>Loading...</p>
      ) : (
        results.map((attraction) => (
          <div key={attraction.id}>
            <Link to={`/attractions/${attraction.id}`}>{attraction.name}</Link>
          </div>
        ))
      )}
    </div>
  );
};

export default SearchAttractions;
