import React, {useState, useEffect} from 'react';
import {useParams, Link} from 'react-router-dom';
import {fetchEvents} from '../api';
import Pagination from './Pagination';

const EventsList=() => {
  const { page }=useParams();
  const [events, setEvents]=useState([]);
  const [loading, setLoading]=useState(true);
  const [totalPages, setTotalPages]=useState(1);

  useEffect(() => {
    const getEvents=async () => {
      setLoading(true);
      try{
        const data=await fetchEvents(page);
        setEvents(data._embedded.events);
        setTotalPages(data.page.totalPages);
      }
      catch(e){
        console.error(e);
      }
      finally {
        setLoading(false);
      }
    };
    getEvents();
  }, [page]);

  return (
    <div>
      <h1>Events</h1>
      {loading ? (<p>Loading...</p>)
      :(
        events.map((event) => (
          <div key={event.id}>
            <Link to={`/events/${event.id}`}>{event.name}</Link>
          </div>
        ))
      )}
      <Pagination currentPage={parseInt(page)} totalPages={totalPages} path="/events/page/" />
    </div>
  );
};

export default EventsList;
