import React, {useState, useEffect} from 'react';
import {useParams, useNavigate} from 'react-router-dom';
import {fetchVenueById} from '../api';

const VenueDetails=() => {
  const {id}=useParams();
  const [venue, setVenue]=useState(null);
  const navigate=useNavigate();

  useEffect(()=> {
    const getVenue=async () => {
      try {
        const temp=await fetchVenueById(id);
        setVenue(temp);
      }
      catch(e){
        navigate('/404');
      }
    };
    getVenue();
  }, [id, navigate]);

  return (
    <div>
      {venue ? (
        <>
          <h2>{venue.name}</h2>
          <p>Address: {venue.address?.line1 || 'No address available'}</p>
          <p>City: {venue.city?.name}</p>
          <p>Country: {venue.country?.name}</p>
        </>
      )
      :(
        <p>Loading...</p>
      )}
    </div>
  );
};

export default VenueDetails;
