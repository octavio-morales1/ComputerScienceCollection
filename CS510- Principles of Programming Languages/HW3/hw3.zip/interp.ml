open Parser_plaf.Ast
open Parser_plaf.Parser
open Ds

(*
  Name: Octavio Morales
  Assignment 3
*)
  
(** [eval_expr e] evaluates expression [e] *)
let rec eval_expr : expr -> exp_val ea_result =
  fun e ->
  match e with
  | Int(n) ->
    return (NumVal n)
  | Var(id) ->
    apply_env id
  | Add(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1+n2))
  | Sub(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1-n2))
  | Mul(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1*n2))
  | Div(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    if n2==0
    then error "Division by zero"
    else return (NumVal (n1/n2))
  | Let(id,def,body) ->
    eval_expr def >>= 
    extend_env id >>+
    eval_expr body 
  | ITE(e1,e2,e3) ->
    eval_expr e1 >>=
    bool_of_boolVal >>= fun b ->
    if b 
    then eval_expr e2
    else eval_expr e3
  | IsZero(e) ->
    eval_expr e >>=
    int_of_numVal >>= fun n ->
    return (BoolVal (n = 0))
  | Debug(_e) ->
    string_of_env >>= fun str ->
    print_endline str; 
    error "Debug called"

  | IsEmpty e1 ->
    eval_expr e1 >>= fun v ->
    findT v >>= fun t ->
    (match t with
      | Empty-> return (BoolVal true)
      | _-> return (BoolVal false))
  | EmptyTree _t->
    return (TreeVal Empty)
  | Node (e1, e2, e3)->
    eval_expr e1>>= fun vdata->
    eval_expr e2>>= fun vleft->
    eval_expr e3>>= fun vright->
    findT vleft >>= fun tleft->
    findT vright >>= fun tright->
    return (TreeVal (Node (vdata, tleft, tright)))
  | CaseT (e_scrut, e_when_empty, id1, id2, id3, e_when_node)->
    eval_expr e_scrut >>= fun v->
    findT v >>= fun t->
    (match t with
      | Empty->
        eval_expr e_when_empty
      | Node (vdata, tleft, tright)->
        extend_env id1 vdata >>+
        extend_env id2 (TreeVal tleft)>>+
        extend_env id3 (TreeVal tright)>>+
        eval_expr e_when_node)
  | Record fs->
    let names= List.map fst fs in
    noDups names >>= fun ()->
    let rec eval_fields acc= function
      | []-> return (List.rev acc)
      | (name,(mut,ex))::tl ->
        eval_expr ex >>= fun v ->
        eval_fields ((name, (mut, v))::acc) tl
      in eval_fields [] fs >>= fun evaluated->
        return (RecordVal evaluated)
  | Proj (e_rec, fld)->
      eval_expr e_rec >>= fun vrec->
      findR vrec >>= fun fs->
      (match lkField fld fs with
        | Some v-> return v
        | None-> error "Proj: field does not exist")
  | _-> failwith "Not implemented yet!"

(** [eval_prog e] evaluates program [e] *)
let eval_prog (AProg(_,e)) =
  eval_expr e

(** [interp s] parses [s] and then evaluates it *)
let interp (e:string) : exp_val result =
  let c = e |> parse |> eval_prog
  in run c
  


