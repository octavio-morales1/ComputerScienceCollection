open ReM
open Dst
open Parser_plaf.Ast
open Parser_plaf.Parser

(*Octavio Morales*)
let rec chk_expr : expr -> texpr tea_result = function 
  | Int _n -> return IntType
  | Var id -> apply_tenv id
  | IsZero(e) ->
    chk_expr e >>= fun t ->
    if t=IntType
    then return BoolType
    else error "isZero: expected argument of type int"
  | Add(e1,e2) | Sub(e1,e2) | Mul(e1,e2)| Div(e1,e2) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    if (t1=IntType && t2=IntType)
    then return IntType
    else error "arith: arguments must be ints"
  | ITE(e1,e2,e3) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    chk_expr e3 >>= fun t3 ->
    if (t1=BoolType && t2=t3)
    then return t2
    else error "ITE: condition not boolean or types of then and else do not match"
  | Let(id,e,body) ->
    chk_expr e >>= fun t ->
    extend_tenv id t >>+
    chk_expr body
  | Proc(var,Some t1,e) ->
    extend_tenv var t1 >>+
    chk_expr e >>= fun t2 ->
    return @@ FuncType(t1,t2)
  | Proc(_var,None,_e) ->
    error "proc: type declaration missing"
  | App(e1,e2) ->
    chk_expr e1 >>=
    pair_of_funcType "app: " >>= fun (t1,t2) ->
    chk_expr e2 >>= fun t3 ->
    if t1=t3
    then return t2
    else error "app: type of argument incorrect"
  | Letrec([(_id,_param,None,_,_body)],_target) | Letrec([(_id,_param,_,None,_body)],_target) ->
    error "letrec: type declaration missing"
  | Letrec([(id,param,Some tParam,Some tRes,body)],target) ->
    extend_tenv id (FuncType(tParam,tRes)) >>+
    (extend_tenv param tParam >>+
     chk_expr body >>= fun t ->
     if t=tRes 
     then chk_expr target
     else error
         "LetRec: Type of recursive function does not match declaration")
  | EmptyHtbl (tKey, tVal)->
    (match tKey, tVal with
      | Some temp1, Some temp2->
        return (HtblType (temp1,temp2))
      | _->
        error "EmptyHtbl: type annotation missing"
    )
  | InsertHtbl (e1, e2, e3)->
    chk_expr e1>>= fun t1->
      chk_expr e2>>= fun t2->
        chk_expr e3>>= fun t3->
          (match t3 with
            | HtblType (k, v)->
              if t1=k && t2=v
                then return t3
                else error "InsertHtbl: key and/or value types do not match table type"
            | _->
              error "InsertHtbl: argument is not a hash table"
          )
  | LookupHtbl(e1, e2)->
    chk_expr e1>>= fun t1->
      chk_expr e2>>= fun t2->
        (match t2 with
          | HtblType(k,v)->
            if t1=k
              then return v
              else error "Lookup: Key not found."
        | _->
          error "Lookup: second argument is not a hash table"
        )
  | RemoveHtbl(e1, e2)->
    chk_expr e1 >>= fun t1->
      chk_expr e2 >>= fun t2->
        (match t2 with
          | HtblType (k,v)->
            if t1=k
              then return t2
              else error "Remove: Key not found."
          | _->
            error "Remove: second argument is not a hash table"
        )
  | IsEmpty e->
    chk_expr e>>= fun t->
      (match t with
        | HtblType(_, _)-> return BoolType
        | _-> error "empty?: argument must be a hash table"
      )

  | Size e->
    chk_expr e >>= fun t->
      (match t with
        | HtblType(_, _)-> return IntType
        | _-> error "Size: argument must be a hash table"
      )

  | Debug(_e) ->
    string_of_tenv >>= fun str ->
    print_endline str;
    error "Debug: reached breakpoint"
  | _ -> failwith "chk_expr: implement"    
and
  chk_prog (AProg(_,e)) =
  chk_expr e

(* Type-check an expression *)
let chk (e:string) : texpr result =
  let c = e |> parse |> chk_prog
  in run_teac c

let chkpp (e:string) : string result =
  let c = e |> parse |> chk_prog
  in run_teac (c >>= fun t -> return @@ string_of_texpr t)



