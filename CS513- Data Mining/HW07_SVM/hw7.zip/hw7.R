# Name: Octavio Morales
# CWID: 20006348
# Assignment: Homework 7- SVM
library(e1071)
library(caret)
library(dplyr)

# Load and prepare data
data <- read.csv("C:/Users/octpr/Desktop/help/cs513/wisc_bc_ContinuousVar.csv")
str(data)
summary(data)
colnames(data)
unique(data$diagnosis)
if (is.character(data$diagnosis) || is.numeric(data$diagnosis)) {
  data$diagnosis <- as.factor(data$diagnosis)
}
str(data$diagnosis)

#Normalize features and split for training
data[,-c(1,2)] <- scale(data[,-c(1,2)])
set.seed(123)
trainIndex <- createDataPartition(data$diagnosis, p = 0.8, list = FALSE)
trainData <- data[trainIndex, ]
testData <- data[-trainIndex, ]
tuneResult <- tune.svm(diagnosis ~ ., data = trainData, 
                       kernel = "radial", 
                       cost = 10^(-1:2), 
                       gamma = c(0.5, 1, 2))
bestModel <- tuneResult$best.model
summary(bestModel)

predictions <- predict(bestModel, testData)
confusionMatrix(predictions, testData$diagnosis)
