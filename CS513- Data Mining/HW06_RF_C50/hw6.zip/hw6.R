# Name: Octavio Morales
# CWID: 20006348
# Assignment: Homework 6- RF/C50

library(C50)
library(randomForest)

# Load and prepare the data
data <- read.csv("C:/Users/octpr/Desktop/help/cs513/breast-cancer-wisconsin.csv") #Change depending on device
data$Class <- as.factor(data$Class)
factor_columns <- c("F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9")
data[factor_columns] <- lapply(data[factor_columns], as.factor)
data$F6 <- as.factor(data$F6)
set.seed(123)
train_index <- sample(seq_len(nrow(data)), size = 0.7 * nrow(data))
train_data <- data[train_index, ]
test_data <- data[-train_index, ]

# 6.1- C50
c50_model <- C5.0(Class ~ ., data = train_data)
c50_predictions <- predict(c50_model, test_data)
c50_confusion <- table(test_data$Class, c50_predictions)
c50_accuracy <- sum(diag(c50_confusion)) / sum(c50_confusion)
print(paste("6.1 C5.0 Model Accuracy:", round(c50_accuracy * 100, 2), "%"))

# 6.2- RF
rf_model <- randomForest(Class ~ ., data = train_data, importance = TRUE)
rf_predictions <- predict(rf_model, test_data)
rf_confusion <- table(test_data$Class, rf_predictions)
rf_accuracy <- sum(diag(rf_confusion)) / sum(rf_confusion)
print(paste("6.2 Random Forest Model Accuracy:", round(rf_accuracy * 100, 2), "%"))

#Displaying models
importance(rf_model)
varImpPlot(rf_model)
